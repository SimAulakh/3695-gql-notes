const graphql = require('graphql');
const_=require('lodash');

const {GraphQLObejctType,GraphQLString,GraphQLSchema} = graphql;

//mock data
var notes = [
    {id:1, title:'Chem class 1', subject: 'Chem 101', content:'These are the notes for week 1 Chemistry', date: 'September 8, 2020', reminder: 'Quiz 1 in next class'},
    {id:2, title:'Phys class 1', subject: 'Phys 101', content:'These are the notes for week 1 Physics', date: 'September 9, 2020', reminder: 'Quiz 1 in next class'},
    {id:3, title:'Chem class 1', subject: 'Math 101', content:'These are the notes for week 1 Maths', date: 'September 10, 2020', reminder: 'Quiz 1 in next class'}
];

const NoteType = new GraphQLObejctType({
    name:'Notes',
    fields:() => ({
        id: {type: GraphQLString},
        title: {type: GraphQLString},
		subject: {type: GraphQLString},
		content: {type: GraphQLString},
        date: {type: GraphQLString},
        reminder: {type: GraphQLString}
    })
});


//#1 Query and resolver - single note
const RootQuery = new GraphQLObejctType({
    name: 'RootQueryType',
    fields:{
        singlenote:{
            type: NoteType,
            args:{id:{type:GraphQLString}},
            resolve(parent,args){
                //finds one note from the mock data
                return _.find(notes, {id:args.id});
            }
        }
    }
});

//#2 Query and resolver - all notes
const RootQueryTwo = new GraphQLObejctType({
    name: 'RootQueryType',
    fields:{
        allnotes:{
            type: NoteType,
            resolve(parent){
                //gets all notes from the mock data
                return _.find(notes);
            }
        }
    }
});

//#3 Query and resolver - reminder feature
const RootQueryThree = new GraphQLObejctType({
    name: 'RootQueryType',
    fields:{
        notification:{
            type: NoteType,
            args:{id:{type:GraphQLString}},
            resolve(parent,args){
                //finds the note with the given id and returns the reminder set for that note.
                return _.find(notes.reminder, {id:args.id});
            }
        }
    }
});

module.exports= new GraphQLSchema({
    query:RootQuery,
    query:RootQueryTwo,
    query:RootQueryThree
});